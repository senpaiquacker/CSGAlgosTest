using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;
public class Vertex
{
    public enum VertexStatus
    {
        Unknown = 0,
        Inside = 1,
        Outside = 5,
        Boundary = 10
    }
    public Vector3 LocalPosition { get; set; }

    public Vector3 GetGlobal(Transform parent) => parent.localToWorldMatrix.MultiplyPoint3x4(LocalPosition);

    public List<Vertex> neighbours;

    public VertexStatus Status { get; set; }

    public List<Vertex> GetAreaWithSameStatus()
    {
        var answ = new List<Vertex>();
        foreach(var v in neighbours)
        {
            if(v.Status == Status)
                answ.AddRange(v.GetAreaWithSameStatus());
        }
        answ.Add(this);
        return answ.Distinct().ToList();
    }
    public Vertex(Vector3 pos)
    {
        neighbours = new List<Vertex>();
        LocalPosition = pos;
        Status = VertexStatus.Unknown;
    }
}
