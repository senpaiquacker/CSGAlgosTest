using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Collider), typeof(PrimitiveMesh))]
public class SculptMesh : MonoBehaviour
{
    /*private Collider collider;
    private void Awake()
    {
        collider = GetComponent<Collider>();
        collider.isTrigger = true;
    }
    */
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
