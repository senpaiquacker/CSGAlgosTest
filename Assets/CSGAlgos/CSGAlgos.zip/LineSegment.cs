using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class IntersectionSegment
{
    public (Vector3 p, Vector3 d) LineEquation;
    public enum PointType
    {
        None = 0,
        Vertex = 1,
        Edge = 2,
        Face = 3
    }
    public float FirstPointK;
    public float SecondPointK;
    public float MiddlePointK => (FirstPointK + SecondPointK) / 2;
    public (PointType s, PointType m, PointType l) SegmentProperties;
    public (int firstPrevious, int lastPrevious) PrecedingVertices;

    private IntersectionSegment() { }
    public static void CheckIntersection(
        Polygon polyA, Polygon polyB, 
        IEnumerable<float> ADistances, IEnumerable<float> BDistances,
        out IntersectionSegment AIntersection, out IntersectionSegment BIntersection)
    {
        AIntersection = new IntersectionSegment();
        BIntersection = new IntersectionSegment();
        var a = polyA.Parent.ToGlobal(polyA.PlaneEquation);
        var b = polyB.Parent.ToGlobal(polyA.PlaneEquation);
        var d = Vector3.Cross(a.normal, b.normal);
        var p = new Vector3(
            (a.D * b.normal.y - b.D * a.normal.y),
            (b.D * a.normal.x - a.D * b.normal.x),
            0) / (b.normal.x * a.normal.y - a.normal.x * b.normal.y);
        AIntersection.LineEquation = (p, d);
        BIntersection.LineEquation = (p, d);
        var APoints = GetLineSegment(AIntersection.LineEquation, polyA, ADistances, out AIntersection.PrecedingVertices, 
            out AIntersection.SegmentProperties);
        var BPoints = GetLineSegment(BIntersection.LineEquation, polyB, BDistances, out BIntersection.PrecedingVertices,
            out BIntersection.SegmentProperties);
        AIntersection.FirstPointK = APoints.k1;
        AIntersection.SecondPointK = APoints.k2;
        BIntersection.FirstPointK = BPoints.k1;
        BIntersection.SecondPointK = BPoints.k2;
    }
    private static (float k1, float k2) GetLineSegment(
        (Vector3 p, Vector3 d) line, Polygon polygon, IEnumerable<float> distances, 
        out (int first, int last) precedingVertices,
        out (PointType first, PointType middle, PointType last) segmentType)
    {
        (float k1, float k2) points = (0, 0);
        precedingVertices = (-1, -1);
        segmentType = (0, 0, 0);

        var dists = distances.ToArray();
        bool isSecond = false;
        for (int i = 0; i < polygon.Vertices.Length; i++)
        {
            if(dists[i] == 0)
            {
                if (!isSecond)
                {
                    isSecond = true;
                    precedingVertices.first = i;
                    segmentType.first = PointType.Vertex;
                }
                else
                {
                    precedingVertices.last = i;
                    segmentType.last = PointType.Vertex;
                    if(segmentType.first == PointType.Vertex)
                    {
                        if (precedingVertices.first + 1 == precedingVertices.last)
                            segmentType.middle = PointType.Edge;
                        else
                            segmentType.middle = PointType.Face;
                    }
                    else if(segmentType.first == PointType.Edge)
                        segmentType.middle = PointType.Face;
                    break;
                }
            }
            else if(Mathf.Sign(dists[i]) != Mathf.Sign(dists[(i + 1) % dists.Length]))
            {
                if(!isSecond)
                {
                    isSecond = true;
                    precedingVertices.first = i;
                    segmentType.first = PointType.Edge;
                }
                else
                {
                    precedingVertices.last = i;
                    segmentType.last = PointType.Edge;
                    if (segmentType.first == PointType.Vertex)
                        segmentType.middle = PointType.Face;
                    else if (segmentType.first == PointType.Edge)
                        segmentType.middle = PointType.Face;
                    break;
                }
            }
        }
        if (precedingVertices.last == -1 && segmentType.first == PointType.Vertex)
        {
            precedingVertices.last = precedingVertices.first;
            segmentType.middle = segmentType.last = PointType.Vertex;
        }
        if (segmentType.first == PointType.None ||
           segmentType.middle == PointType.None ||
           segmentType.last == PointType.None)
            throw new System.Exception("Invalid Polygon");
        points.k1 =
            segmentType.first == PointType.Vertex ?
            Vector3.Dot(line.p + line.d, polygon.Parent.ToGlobal(polygon.Vertices[precedingVertices.first]) - line.p) :
            GetLineEdgeIntersection(line, 
            (polygon.Parent.ToGlobal(polygon.Vertices[precedingVertices.first]), 
            polygon.Parent.ToGlobal(polygon.Vertices[(precedingVertices.first + 1) % polygon.Vertices.Length])),
            (dists[precedingVertices.first], dists[(precedingVertices.first + 1) % polygon.Vertices.Length]));

        points.k2 = segmentType.last == PointType.Vertex ?
            Vector3.Dot(line.p + line.d, polygon.Parent.ToGlobal(polygon.Vertices[precedingVertices.first]) - line.p) :
            GetLineEdgeIntersection(line,
            (polygon.Parent.ToGlobal(polygon.Vertices[precedingVertices.last]),
            polygon.Parent.ToGlobal(polygon.Vertices[(precedingVertices.last + 1) % polygon.Vertices.Length])),
            (dists[precedingVertices.last], dists[(precedingVertices.last + 1) % polygon.Vertices.Length]));
        if(points.k2 < points.k1)
        {
            var k3 = points.k1;
            points.k1 = points.k2;
            points.k2 = k3;
            var i3 = precedingVertices.first;
            precedingVertices.first = precedingVertices.last;
            precedingVertices.last = i3;
        }
        return points;
    }
    private static float GetLineEdgeIntersection((Vector3 p, Vector3 d) line, (Vector3 x1, Vector3 x2) edge, (float d1, float d2) distancesToLine)
    {
        var eLine = (p: edge.x1, d: edge.x2 - edge.x1);
        var sumDist = distancesToLine.d1 + distancesToLine.d2;
        var aok = distancesToLine.d1 / sumDist;
        var ao = eLine.d * aok;
        return (ao - line.p).magnitude;
    }
    public static bool CheckIntersection(IntersectionSegment segA, IntersectionSegment segB, out IntersectionSegment intersection)
    {
        intersection = segA;
        if (segA.SecondPointK >= segB.FirstPointK && segA.SecondPointK <= segB.FirstPointK)
        {
            if(segA.FirstPointK >= segB.FirstPointK)
            {
                intersection = SwapByVerticesOrder(intersection);
                return true;
            }
            else
            {
                intersection.FirstPointK = segB.FirstPointK;
                intersection.SegmentProperties.s = intersection.SegmentProperties.m;
                intersection = SwapByVerticesOrder(intersection);
                return true;
            }
        }
        else if(segA.FirstPointK >= segB.FirstPointK && segB.SecondPointK < segA.FirstPointK)
        {
            intersection.SecondPointK = segB.SecondPointK;
            intersection.SegmentProperties.l = intersection.SegmentProperties.m;
            intersection = SwapByVerticesOrder(intersection);
            return true;
        }
        else if(segB.FirstPointK > segA.FirstPointK && segB.SecondPointK < segA.SecondPointK)
        {
            intersection.FirstPointK = segB.FirstPointK;
            intersection.SecondPointK = segB.SecondPointK;
            intersection.SegmentProperties.s = intersection.SegmentProperties.l = intersection.SegmentProperties.m;
            intersection = SwapByVerticesOrder(intersection);
            return true;
        }
        else
        {
            return false;
        }
    }
    //Method swaps intersection order as in descending preceding vertices id order so that the 0-point of poly vertices is always above both of them logically
    private static IntersectionSegment SwapByVerticesOrder(IntersectionSegment intersection)
    {
        if (intersection.PrecedingVertices.firstPrevious < intersection.PrecedingVertices.lastPrevious)
        {
            var k3 = intersection.FirstPointK;
            intersection.FirstPointK = intersection.SecondPointK;
            intersection.SecondPointK = k3;
            var v3 = intersection.PrecedingVertices.firstPrevious;
            intersection.PrecedingVertices.firstPrevious = intersection.PrecedingVertices.lastPrevious;
            intersection.PrecedingVertices.lastPrevious = v3;
            var t3 = intersection.SegmentProperties.s;
            intersection.SegmentProperties.s = intersection.SegmentProperties.l;
            intersection.SegmentProperties.l = t3;
        }
        return intersection;
    }
}

