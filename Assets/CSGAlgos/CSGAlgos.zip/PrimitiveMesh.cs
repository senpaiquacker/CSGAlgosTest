using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;
[RequireComponent(typeof(MeshFilter))]
public class PrimitiveMesh : MonoBehaviour
{
    public (Vector3 min, Vector3 max) ObjectExtent
    {
        get =>
        (
            min: new Vector3
            (
                Vertices[extentIds.min.x].LocalPosition.x,
                Vertices[extentIds.min.y].LocalPosition.y,
                Vertices[extentIds.min.z].LocalPosition.z
            ),
            max: new Vector3
            (
                Vertices[extentIds.max.x].LocalPosition.x,
                Vertices[extentIds.max.y].LocalPosition.y,
                Vertices[extentIds.max.z].LocalPosition.z
            )
        );
    }

    private ((int x, int y, int z) min, (int x, int y, int z) max) extentIds;

    #region Polygons And Vertices
    private Polygon[] polygons;
    public Polygon[] Polygons { get => polygons; }

    private Vertex[] vertices;
    public Vertex[] Vertices { get => vertices; }
    #endregion
    private Mesh mesh;
    // Start is called before the first frame update
    void Start()
    {
        mesh = GetComponent<MeshFilter>().mesh;
        vertices = new Vertex[mesh.vertices.Length];
        polygons = new Polygon[mesh.triangles.Length / 3];
        var i = 0;
        foreach(var v in mesh.vertices)
        {
            vertices[i] = new Vertex(v);
            i++;
        }
        extentIds = Extent.UpdateExtent(vertices.Select(a => a.LocalPosition));
        for (int j = 0; j < mesh.triangles.Length; j += 3)
        {
            polygons[j / 3] = new Polygon
                (this, 
                 (Vertices[mesh.triangles[j]], mesh.triangles[j]), 
                 (Vertices[mesh.triangles[j + 1]], mesh.triangles[j + 1]), 
                 (Vertices[mesh.triangles[j + 2]], mesh.triangles[j + 2]));
        }
        foreach (var v in vertices)
            v.neighbours = v.neighbours.Distinct().ToList();
    }

    public void AddPolygon(Polygon newPoly, params Vertex[] newVerts)
    {
        if (newVerts != null)
        {
            vertices = vertices.Concat(newVerts).ToArray();
            mesh.vertices = vertices.Select(a => a.LocalPosition).ToArray();
        }
        mesh.triangles = mesh.triangles.Concat(newPoly.vertIds).ToArray();
    }
    public (Vector3 emin, Vector3 emax) ToGlobal() =>
    (
        emin: transform.localToWorldMatrix.MultiplyPoint3x4(ObjectExtent.min), 
        emax: transform.localToWorldMatrix.MultiplyPoint3x4(ObjectExtent.max)
    );
    public (Vector3 normal, float D) ToGlobal((Vector3 normal, float D) planeEquation)
    {
        var plane = new Vector4(planeEquation.normal.x, planeEquation.normal.y, planeEquation.normal.z, planeEquation.D);
        var newPlane = transform.localToWorldMatrix.inverse.transpose * plane;
        return (newPlane, newPlane.w);
    }
    private Vector3 ToGlobal(Vector3 point) => transform.localToWorldMatrix.MultiplyPoint3x4(point);
    public Vector3 ToGlobal(Vertex vertex) => transform.localToWorldMatrix.MultiplyPoint3x4(vertex.LocalPosition);
    public (Vector3 emin, Vector3 emax) ToGlobal(Polygon polygon) =>
    (
        emin: transform.localToWorldMatrix.MultiplyPoint3x4(polygon.PolyExtent.min),
        emax: transform.localToWorldMatrix.MultiplyPoint3x4(polygon.PolyExtent.max)
    );
    public Vector3 ToLocal(Vector3 anyPoint) => transform.worldToLocalMatrix.MultiplyPoint3x4(anyPoint);
    // Update is called once per frame
    void Update()
    {
    }
}
