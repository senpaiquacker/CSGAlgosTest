using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;
public class OperationsAlgorithms
{
    // Start is called before the first frame update
    public static void CalculateSubmeshes(PrimitiveMesh A, PrimitiveMesh B)
    {
        Divide(A, B);
        Divide(B, A);
        Divide(A, B);
    }
    private static void Divide(PrimitiveMesh A, PrimitiveMesh B)
    {
        var Aex = A.ToGlobal();
        var Bex = B.ToGlobal();
        if (Extent.CheckIntersection(Aex, Bex))
        {
            foreach (var polyA in A.Polygons)
            {
                if (Extent.CheckIntersection(A.ToGlobal(polyA), Bex))
                {
                    foreach (var polyB in B.Polygons)
                    {
                        if (Extent.CheckIntersection(A.ToGlobal(polyA), B.ToGlobal(polyB)))
                        {
                            IEnumerable<float> distances;
                            var inter = GetTwoPolygonsIntersection(polyA, polyB, out distances);
                            if(inter == Intersection.CoplanarIntersection || inter == Intersection.NoIntersection)
                                continue;
                            else
                                SubdivideNonCoplanar(polyA, polyB, distances);
                        }
                    }
                }
            }
        }
    }
    public static Intersection GetTwoPolygonsIntersection(Polygon polyA, Polygon polyB, out IEnumerable<float> distances, bool IsReversed = false)
    {
        bool isCoplanar = true;
        int k = 0;
        distances = polyA.Vertices.Select(a =>
        {
            var dist = polyB.GetSignedDistance(polyA.Parent.ToGlobal(a));
            if (Mathf.Abs(dist) > 0.01f)
            {
                isCoplanar = false;
                k += (int)Mathf.Sign(dist);
            }
            return dist;
        });
        if(Mathf.Abs(k) == polyA.Vertices.Length)
            return Intersection.CoplanarIntersection;
        else if(isCoplanar)
            return 0;
        else
        {
            if(IsReversed)
                return Intersection.PointLineIntersection;
            IEnumerable<float> BtoA;
            var answ = GetTwoPolygonsIntersection(polyB, polyA, out BtoA, true);
            distances = distances.Concat(BtoA);
            return answ;
        }
    }
    public static void SubdivideNonCoplanar(Polygon polyA, Polygon polyB, IEnumerable<float> allDistances)
    {
        var ADistances = allDistances.Take(polyA.Vertices.Length);
        var BDistances = allDistances.Skip(polyA.Vertices.Length);
        IntersectionSegment ASeg, BSeg;
        IntersectionSegment.CheckIntersection(polyA, polyB, ADistances, BDistances,  out ASeg, out BSeg);
        IntersectionSegment AinB, BinA;
        if (!IntersectionSegment.CheckIntersection(ASeg, BSeg, out AinB)
         || !IntersectionSegment.CheckIntersection(BSeg, ASeg, out BinA))
            return;
        DeclareSubdivisionCase(polyA, AinB);
        DeclareSubdivisionCase(polyB, BinA);
    }
    private static void DeclareSubdivisionCase(Polygon polyA, IntersectionSegment AinB)
    {
        switch (AinB.SegmentProperties)
        {
            //1 (1)
            case (IntersectionSegment.PointType.Vertex, IntersectionSegment.PointType.Vertex, IntersectionSegment.PointType.Vertex):
                CallCase_1(polyA, AinB);
                break;
            //2 (4)
            case (IntersectionSegment.PointType.Vertex, IntersectionSegment.PointType.Edge, IntersectionSegment.PointType.Vertex):
                CallCase_2(polyA, AinB);
                break;
            //3 (5) and Sym-3 (13)
            case (IntersectionSegment.PointType.Vertex, IntersectionSegment.PointType.Edge, IntersectionSegment.PointType.Edge):
            case (IntersectionSegment.PointType.Edge, IntersectionSegment.PointType.Vertex, IntersectionSegment.PointType.Vertex):
                CallCase_3(polyA, AinB);
                break;
            //4 (7)
            case (IntersectionSegment.PointType.Vertex, IntersectionSegment.PointType.Face, IntersectionSegment.PointType.Vertex):
                CallCase_4(polyA, AinB);
                break;
            //5 (8) and Sym-5 (16)
            case (IntersectionSegment.PointType.Vertex, IntersectionSegment.PointType.Face, IntersectionSegment.PointType.Edge):
            case (IntersectionSegment.PointType.Edge, IntersectionSegment.PointType.Face, IntersectionSegment.PointType.Vertex):
                CallCase_5(polyA, AinB);
                break;
            //6 (9) and Sym-6 (25)
            case (IntersectionSegment.PointType.Vertex, IntersectionSegment.PointType.Face, IntersectionSegment.PointType.Face):
            case (IntersectionSegment.PointType.Face, IntersectionSegment.PointType.Face, IntersectionSegment.PointType.Vertex):
                CallCase_6(polyA, AinB);
                break;
            //7 (14)
            case (IntersectionSegment.PointType.Edge, IntersectionSegment.PointType.Edge, IntersectionSegment.PointType.Edge):
                CallCase_7(polyA, AinB);
                break;
            //8 (17)
            case (IntersectionSegment.PointType.Edge, IntersectionSegment.PointType.Face, IntersectionSegment.PointType.Edge):
                CallCase_8(polyA, AinB);
                break;
            //9 (18) and Sym-9 (26)
            case (IntersectionSegment.PointType.Edge, IntersectionSegment.PointType.Face, IntersectionSegment.PointType.Face):
            case (IntersectionSegment.PointType.Face, IntersectionSegment.PointType.Face, IntersectionSegment.PointType.Edge):
                CallCase_9(polyA, AinB);
                break;
            //10 (27)
            case (IntersectionSegment.PointType.Face, IntersectionSegment.PointType.Face, IntersectionSegment.PointType.Face):
                CallCase_10(polyA, AinB);
                break;
            //others (2, 3, 6, 10, 11, 12, 15, 19, 20, 21, 22, 23, 24)
            default:
                throw new System.Exception("Invalid Polygon");
        }
    }
    private static void CallCase_1(Polygon poly, IntersectionSegment seg) => poly.Vertices[seg.PrecedingVertices.firstPrevious].Status = Vertex.VertexStatus.Boundary;
    private static void CallCase_2(Polygon poly, IntersectionSegment seg)
    {
        poly.Vertices[seg.PrecedingVertices.firstPrevious].Status = Vertex.VertexStatus.Boundary;
        poly.Vertices[seg.PrecedingVertices.lastPrevious].Status = Vertex.VertexStatus.Boundary;
    }
    private static void CallCase_3(Polygon poly, IntersectionSegment seg)
    {
        Vertex newV;
        if (seg.SegmentProperties.s == IntersectionSegment.PointType.Edge)
        {
            newV = new Vertex(seg.LineEquation.p + seg.FirstPointK * seg.LineEquation.d);
            poly.Vertices[seg.PrecedingVertices.lastPrevious].Status = Vertex.VertexStatus.Boundary;
        }
        else
        {
            newV = new Vertex(seg.LineEquation.p + seg.SecondPointK * seg.LineEquation.d);
            poly.Vertices[seg.PrecedingVertices.firstPrevious].Status = Vertex.VertexStatus.Boundary;
        }
        //No matter, in start is point on edge, or at the end -
        // you connect to last's previous
        // (counts as same as end point if edge in start, and as previous, if edge in end)
        var newPoly = new Polygon(poly.Parent, 
            //new Vertex
            (newV, poly.Parent.Vertices.Length),
            //Previous of lastprevious (to Connect)
            (poly.Vertices[seg.PrecedingVertices.lastPrevious - 1], poly.vertIds[seg.PrecedingVertices.lastPrevious - 1]),
            //Previous of last
            (poly.Vertices[seg.PrecedingVertices.lastPrevious], poly.vertIds[seg.PrecedingVertices.lastPrevious]));
        //find next vertex to a newadded vertex
        var vertexToConnect =
            seg.PrecedingVertices.firstPrevious != seg.PrecedingVertices.lastPrevious ?
            poly.Vertices[seg.PrecedingVertices.firstPrevious] :
            poly.Vertices[seg.PrecedingVertices.firstPrevious + 1];
        //replace disconnected vertices to a newone
        newV.neighbours.Add(vertexToConnect);
        vertexToConnect.neighbours.Remove(poly.Vertices[seg.PrecedingVertices.lastPrevious]);
        vertexToConnect.neighbours.Add(newV);
        //Add newcreated Polygon
        poly.Parent.AddPolygon(newPoly, newV);
        poly.Vertices[seg.PrecedingVertices.lastPrevious] = newV;
        poly.vertIds[seg.PrecedingVertices.lastPrevious] = poly.Parent.Vertices.Length - 1;
        newV.Status = Vertex.VertexStatus.Boundary;
    }
    private static void CallCase_4(Polygon poly, IntersectionSegment seg)
    {
        Polygon newP;
        List<(Vertex vert, int id)> newPvertices = new List<(Vertex vert, int id)>();
        List<(Vertex vert, int id)> oldPvertices = new List<(Vertex vert, int id)>();
        DivideBySegmentVertices(poly, seg, out newPvertices, out oldPvertices);
        newP = new Polygon(poly.Parent, newPvertices[0], newPvertices[1], newPvertices[2], newPvertices.Skip(3).ToArray());
        poly.Vertices = oldPvertices.Select(a => a.vert).ToArray();
        poly.vertIds = oldPvertices.Select(a => a.id).ToArray();
        poly.Parent.AddPolygon(newP);
        poly.Vertices[seg.PrecedingVertices.firstPrevious].Status = 
        poly.Vertices[seg.PrecedingVertices.lastPrevious].Status = Vertex.VertexStatus.Boundary;
    }
    private static void CallCase_5(Polygon poly, IntersectionSegment seg)
    {
        int countedPreceeding = seg.SegmentProperties.s == IntersectionSegment.PointType.Edge ? seg.PrecedingVertices.firstPrevious : seg.PrecedingVertices.lastPrevious;
        float countedK;
        if(seg.SegmentProperties.s == IntersectionSegment.PointType.Edge)
        {
            countedPreceeding = seg.PrecedingVertices.firstPrevious;
            countedK = seg.FirstPointK;
            seg.PrecedingVertices.firstPrevious++;
        }
        else
        {
            countedPreceeding = seg.PrecedingVertices.lastPrevious;
            countedK = seg.SecondPointK;
            seg.PrecedingVertices.lastPrevious++;
        }
        var newV = new Vertex(seg.LineEquation.p + countedK * seg.LineEquation.d);;

        var newVerts = poly.Vertices.ToList();
        newVerts.Insert(countedPreceeding, newV);
        poly.Vertices = newVerts.ToArray();
        var newPvertices = new List<(Vertex vert, int id)>();
        var oldPvertices = new List<(Vertex vert, int id)>();
        DivideBySegmentVertices(poly, seg, out newPvertices, out oldPvertices);
        var newP = new Polygon(poly.Parent, newPvertices[0], newPvertices[1], newPvertices[2], newPvertices.Skip(3).ToArray());
        poly.Vertices = oldPvertices.Select(a => a.vert).ToArray();
        poly.vertIds = oldPvertices.Select(a => a.id).ToArray();
        poly.Parent.AddPolygon(newP, newV);
        poly.Vertices[seg.PrecedingVertices.firstPrevious].Status =
        poly.Vertices[seg.PrecedingVertices.lastPrevious].Status = Vertex.VertexStatus.Boundary;
    }
    private static void CallCase_6(Polygon poly, IntersectionSegment seg)
    {
        int countedPreceeding;
        float countedK;
        bool isFirst;
        if(seg.SegmentProperties.s == IntersectionSegment.PointType.Face)
        {
            countedPreceeding = seg.PrecedingVertices.firstPrevious;
            countedK = seg.FirstPointK;
            isFirst = true;
        }
        else
        {
            countedPreceeding = seg.PrecedingVertices.lastPrevious;
            countedK = seg.SecondPointK;
            isFirst = false;
        }
        var cosine = Mathf.Abs(Vector3.Dot(seg.LineEquation.d, poly.Parent.ToGlobal(poly.Vertices[countedPreceeding])));
        var newV = new Vertex(seg.LineEquation.p + seg.LineEquation.d * countedK);
        Polygon[] newPs;
        if(cosine > 0.98f)
        {
            //Is on Line
            //There are 4 polygons, so we create 3 new
            newPs = new Polygon[3];

            //Two of them are exactly the same, no matter where face vector is in segment
            newPs[0] = new Polygon(poly.Parent,
                (newV, poly.Parent.Vertices.Length),
                (poly.Vertices[countedPreceeding - 1], poly.vertIds[countedPreceeding - 1]),
                (poly.Vertices[countedPreceeding], poly.vertIds[countedPreceeding]));
            newPs[1] = new Polygon(poly.Parent,
                (newV, poly.Parent.Vertices.Length),
                (poly.Vertices[countedPreceeding], poly.vertIds[countedPreceeding]),
                (poly.Vertices[(countedPreceeding + 1) % poly.Vertices.Length], poly.vertIds[(countedPreceeding + 1) % poly.Vertices.Length]));

            //but third and fourth do depend on if segment if v-f-f of f-f-v
            if (isFirst)
            {
                //It means that we're looking at f-f-v polygon
                newPs[2] = new Polygon(poly.Parent,
                    //first three vertices =  i - 1, newV, li + all between li and i - 1 (li;i-1)
                    (poly.Vertices[countedPreceeding - 1], poly.vertIds[countedPreceeding - 1]),
                    (newV, poly.Parent.Vertices.Length),
                    (poly.Vertices[seg.PrecedingVertices.lastPrevious], poly.vertIds[seg.PrecedingVertices.lastPrevious]),
                    poly.Vertices
                        .Zip(poly.vertIds, (v, i) => (vert: v, id: i))
                        .Skip(seg.PrecedingVertices.lastPrevious + 1)
                        .Take(countedPreceeding - 2 - seg.PrecedingVertices.lastPrevious)
                        .ToArray());
                poly.Vertices =
                    //the last vertices
                    new [] { newV,  poly.Vertices[(countedPreceeding + 1) % poly.Vertices.Length]}
                    .Concat(poly.Vertices.Skip(countedPreceeding + 1))
                    .Concat(poly.Vertices.Take(seg.PrecedingVertices.lastPrevious))
                    .ToArray();
                poly.vertIds =
                    new[] { poly.Parent.Vertices.Length, poly.vertIds[(countedPreceeding + 1) % poly.Vertices.Length] }
                    .Concat(poly.vertIds.Skip(countedPreceeding + 1))
                    .Concat(poly.vertIds.Take(seg.PrecedingVertices.lastPrevious))
                    .ToArray();
            }
            else
            {
                //Now it's v-f-f polygon
                newPs[2] = new Polygon(poly.Parent,
                    //first three vertices = newV, i + 1, i + 2
                    (newV, poly.Parent.Vertices.Length),
                    (poly.Vertices[(countedPreceeding + 1) % poly.Vertices.Length], poly.vertIds[(countedPreceeding + 1) % poly.Vertices.Length]),
                    (poly.Vertices[(countedPreceeding + 2) % poly.Vertices.Length], poly.vertIds[(countedPreceeding + 2) % poly.Vertices.Length]),
                    poly.Vertices
                        .Zip(poly.vertIds, (v, i) => (vert: v, id: i))
                        .Skip(countedPreceeding + 2)
                        .Take(seg.PrecedingVertices.firstPrevious - countedPreceeding - 2)
                        .ToArray());
                poly.Vertices =
                    new[] { newV, poly.Vertices[seg.PrecedingVertices.firstPrevious] }
                    .Concat(poly.Vertices.Skip(seg.PrecedingVertices.firstPrevious))
                    .Concat(poly.Vertices.Take(countedPreceeding - 1))
                    .ToArray();
                poly.vertIds =
                    new[] { poly.Parent.Vertices.Length, poly.vertIds[seg.PrecedingVertices.firstPrevious] }
                    .Concat(poly.vertIds.Skip(seg.PrecedingVertices.firstPrevious))
                    .Concat(poly.vertIds.Take(countedPreceeding - 1))
                    .ToArray();
            }
        }
        else
        {
            //Not on line
            newPs = new Polygon[2];
            newPs[0] = new Polygon(poly.Parent,
                (newV, poly.Parent.Vertices.Length),
                (poly.Vertices[countedPreceeding], poly.vertIds[countedPreceeding]),
                (poly.Vertices[(countedPreceeding + 1) % poly.Vertices.Length], poly.vertIds[(countedPreceeding + 1) % poly.Vertices.Length]));
            if(isFirst)
            {
                newPs[1] = new Polygon(poly.Parent,
                    (poly.Vertices[seg.PrecedingVertices.firstPrevious], poly.vertIds[seg.PrecedingVertices.firstPrevious]),
                    (newV, poly.Parent.Vertices.Length),
                    (poly.Vertices[seg.PrecedingVertices.lastPrevious], poly.vertIds[seg.PrecedingVertices.lastPrevious]),
                    poly.Vertices
                        .Zip(poly.vertIds, (v, i) => (vert: v, id: i))
                        .Take(seg.PrecedingVertices.firstPrevious - 1)
                        .Skip(seg.PrecedingVertices.lastPrevious)
                        .ToArray());
                poly.Vertices = new[] { newV, poly.Vertices[(countedPreceeding + 1) % poly.Vertices.Length] }
                    .Concat(poly.Vertices.Skip(countedPreceeding + 1))
                    .Concat(poly.Vertices.Take(seg.PrecedingVertices.lastPrevious))
                    .ToArray();
                poly.vertIds = new[] { poly.Parent.Vertices.Length, poly.vertIds[(countedPreceeding + 1) % poly.Vertices.Length] }
                    .Concat(poly.vertIds.Skip(countedPreceeding + 1))
                    .Concat(poly.vertIds.Take(seg.PrecedingVertices.lastPrevious))
                    .ToArray();
            }
            else
            {
                newPs[1] = new Polygon(poly.Parent,
                    (poly.Vertices[seg.PrecedingVertices.firstPrevious], poly.vertIds[seg.PrecedingVertices.firstPrevious]),
                    (newV, poly.Parent.Vertices.Length),
                    (poly.Vertices[seg.PrecedingVertices.lastPrevious + 1], poly.vertIds[seg.PrecedingVertices.lastPrevious + 1]),
                    poly.Vertices
                        .Zip(poly.vertIds, (v, i) => (vert: v, id: i))
                        .Take(seg.PrecedingVertices.firstPrevious - 1)
                        .Skip(seg.PrecedingVertices.lastPrevious + 1)
                        .ToArray());
                poly.Vertices = new[] { newV }
                    .Concat(poly.Vertices.Skip(seg.PrecedingVertices.firstPrevious - 1))
                    .Concat(poly.Vertices.Take(seg.PrecedingVertices.lastPrevious))
                    .ToArray();
                poly.vertIds = new[] { poly.Parent.Vertices.Length }
                    .Concat(poly.vertIds.Skip(seg.PrecedingVertices.firstPrevious - 1))
                    .Concat(poly.vertIds.Take(seg.PrecedingVertices.lastPrevious))
                    .ToArray();
            }
        }
        poly.Parent.AddPolygon(newPs[0], newV);
        for(int i = 1; i < newPs.Length; i++)
            poly.Parent.AddPolygon(newPs[i]);
    }
    private static void CallCase_7(Polygon poly, IntersectionSegment seg)
    {
        if(Mathf.Abs(seg.FirstPointK - seg.SecondPointK) < 0.01f)
        {
            //They are the same point
            var newV = new Vertex(seg.LineEquation.p + seg.FirstPointK * seg.LineEquation.d);
            var newP = new Polygon(poly.Parent,
                (newV, poly.Parent.Vertices.Length),
                (poly.Vertices[(seg.PrecedingVertices.lastPrevious - 1 + poly.Vertices.Length) % poly.Vertices.Length],
                 poly.vertIds[(seg.PrecedingVertices.lastPrevious - 1 + poly.Vertices.Length) % poly.Vertices.Length]),
                (poly.Vertices[seg.PrecedingVertices.lastPrevious], poly.vertIds[seg.PrecedingVertices.lastPrevious]));
            poly.Vertices = new[] { newV }
            .Concat(poly.Vertices.Skip(seg.PrecedingVertices.lastPrevious))
            .Concat(poly.Vertices.Take(seg.PrecedingVertices.lastPrevious))
            .ToArray();
            poly.vertIds = new[] { poly.Parent.Vertices.Length }
            .Concat(poly.vertIds.Skip(seg.PrecedingVertices.lastPrevious))
            .Concat(poly.vertIds.Take(seg.PrecedingVertices.lastPrevious))
            .ToArray();
            poly.Parent.AddPolygon(newP, newV);
        }
        else
        {
            //They Are DifferentPoints
            var newVs = new Vertex[2];
            newVs[0] = new Vertex(seg.LineEquation.p + seg.FirstPointK * seg.LineEquation.d);
            newVs[1] = new Vertex(seg.LineEquation.p + seg.SecondPointK * seg.LineEquation.d);
            var newPs = new Polygon[2];
            newPs[0] = new Polygon(poly.Parent,
                (newVs[1], poly.Parent.Vertices.Length + 1),
                (poly.Vertices[(seg.PrecedingVertices.lastPrevious - 1 + poly.Vertices.Length) % poly.Vertices.Length], 
                poly.vertIds[(seg.PrecedingVertices.lastPrevious - 1 + poly.Vertices.Length) % poly.Vertices.Length]),
                (poly.Vertices[seg.PrecedingVertices.lastPrevious], poly.vertIds[seg.PrecedingVertices.lastPrevious]));
            newPs[1] = new Polygon(poly.Parent,
                (newVs[0], poly.Parent.Vertices.Length),
                (poly.Vertices[(seg.PrecedingVertices.lastPrevious - 1 + poly.Vertices.Length) % poly.Vertices.Length],
                poly.vertIds[(seg.PrecedingVertices.lastPrevious - 1 + poly.Vertices.Length) % poly.Vertices.Length]),
                (newVs[1], poly.Parent.Vertices.Length + 1));
            poly.Parent.AddPolygon(newPs[1], newVs);
            poly.Parent.AddPolygon(newPs[0]);
        }
    }
    private static void CallCase_8(Polygon poly, IntersectionSegment seg)
    {
        var newVs = new Vertex[2];
        newVs[0] = new Vertex(seg.LineEquation.p + seg.FirstPointK * seg.LineEquation.d);
        newVs[1] = new Vertex(seg.LineEquation.p + seg.SecondPointK * seg.LineEquation.d);
        var newVerts = poly.Vertices.ToList();
        newVerts.Insert(seg.PrecedingVertices.firstPrevious, newVs[0]);
        seg.PrecedingVertices.firstPrevious++;
        newVerts.Insert(seg.PrecedingVertices.lastPrevious, newVs[1]);
        seg.PrecedingVertices.lastPrevious++;
        List<(Vertex vert, int id)> newPVertices, oldPVertices;
        DivideBySegmentVertices(poly, seg, out newPVertices, out oldPVertices);
        var newP = new Polygon(poly.Parent, newPVertices[0], newPVertices[1], newPVertices[2], newPVertices.Skip(3).ToArray());
        poly.Vertices = oldPVertices.Select(a => a.vert).ToArray();
        poly.vertIds = oldPVertices.Select(a => a.id).ToArray();
        poly.Parent.AddPolygon(newP, newVs);
    }
    private static void CallCase_9(Polygon poly, IntersectionSegment seg)
    {

    }
    private static void CallCase_10(Polygon poly, IntersectionSegment seg)
    {

    }
    private static void DivideBySegmentVertices(Polygon poly, IntersectionSegment seg, 
        out List<(Vertex vert, int id)> newPvertices, out List<(Vertex vert, int id)> oldPvertices)
    {
        bool isStarted = false;
        newPvertices = new List<(Vertex vert, int id)>();
        oldPvertices = new List<(Vertex vert, int id)>();
        for (int i = seg.PrecedingVertices.lastPrevious; i < poly.Vertices.Length; i++)
        {
            if (i == seg.PrecedingVertices.firstPrevious ||
               i == seg.PrecedingVertices.lastPrevious)
            {
                if (!isStarted)
                {
                    if (newPvertices.Count == 0)
                    {
                        newPvertices.Add((vert: poly.Vertices[i], id: poly.vertIds[i]));
                        isStarted = true;
                    }
                    else
                    {
                        oldPvertices.Add((vert: poly.Vertices[i], id: poly.vertIds[i]));
                        isStarted = true;
                    }
                }
                else
                {
                    if (oldPvertices.Count == 0)
                    {
                        newPvertices.Add((vert: poly.Vertices[i], id: poly.vertIds[i]));
                        isStarted = false;
                    }
                    else
                    {
                        isStarted = false;
                        break;
                    }
                }
            }
            else
            {
                if (isStarted)
                {
                    if (oldPvertices.Count == 0)
                        newPvertices.Add((vert: poly.Vertices[i], id: poly.vertIds[i]));
                    else oldPvertices.Add((vert: poly.Vertices[i], id: poly.vertIds[i]));
                }
            }
            if (i == poly.Vertices.Length - 1 && oldPvertices.Count + newPvertices.Count - 2 < poly.Vertices.Length)
                i = -1;
        }
    }
    public enum Intersection
    {
        NoIntersection = 0,
        PointLineIntersection = 5,
        CoplanarIntersection = 10
    }
}
